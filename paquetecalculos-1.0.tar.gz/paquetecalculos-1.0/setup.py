from setuptools import setup

setup(
    name="paquetecalculos",
    version="1.0",
    description="Paquete cálculos básicos",
    author="CGSM",
    author_email="cmejorada@cic.ipn.mx",
    packages=["calculos","calculos.basicos","calculos.exre"]
)
