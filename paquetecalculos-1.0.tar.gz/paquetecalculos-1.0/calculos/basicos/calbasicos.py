def sumar(op1,op2):
    print("La suma es igual a", op1+op2)
def restar(op1,op2):
    print("La resta es igual a", op1-op2)
def multiplicar(op1,op2):
    print("La multiplicaciónes igual a", op1 * op2)
def dividir(dividendo,divisor):
    print("La división es igual a", dividendo/divisor)
