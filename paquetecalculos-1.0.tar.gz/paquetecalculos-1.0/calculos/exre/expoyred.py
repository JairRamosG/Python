def expon(base,exponente):
    print(base, 'elevado a',exponente,'es igual a',
              base**exponente)
def redondear(numero):
    print(numero,"redoneado es igual a",
              round(numero))
